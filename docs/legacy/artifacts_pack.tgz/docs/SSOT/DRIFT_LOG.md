# DRIFT_LOG.md - StoryMaker + AgentPM Drift Tracking

## Purpose

This document tracks drift from the Single Source of Truth (SSOT) and documents fixes applied to maintain system integrity.

## Drift Entries

### 2025-09-11 — SSOT v1.2 Closeout

- Drift fixed: unified model IDs, `/api/v1/*` only, envelope v1.2 everywhere.
- Guards added: model-lock, retrieval-smoke, proof-integrity, fresh-shell env.
- Policy: services fail-closed if providers not ready; "status:ok with empty payload" is prohibited.

### 2025-09-11 — Stability Fixes

- Issue: Services unstable; QA proofs empty; "status:ok" accepted without validation.
- Fix: Introduced new guards:
  - proof-integrity
  - rerank-monotonic
  - soak-and-concurrency
  - provider-isolation
  - fresh-shell-env
- SSOT v1.2 verified: proofs equal responses, services stable under load, providers isolated.

### 2025-09-11 — Legacy Route Blocking

- Issue: Legacy unversioned routes still accessible, causing API drift.
- Fix: Added `no_legacy_routes_guard.sh` to block non-v1 API usage.
- Result: All public endpoints now under `/api/v1/*` only.
