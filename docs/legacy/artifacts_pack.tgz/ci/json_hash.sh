#!/usr/bin/env bash
set -euo pipefail
# Usage: cat envelope.json | ci/json_hash.sh
# DELEGATES to ci/json_hash.py for single-source canonicalization

if command -v python3 >/dev/null 2>&1; then
  exec python3 ci/json_hash.py
fi
echo "::error ::python3 not found; canonicalizer unavailable" >&2
exit 90
